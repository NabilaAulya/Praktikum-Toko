<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BarangController extends Controller
{
    public function barang()
    {
        echo 'input barang di sini';
    }
}