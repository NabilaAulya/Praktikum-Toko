<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MakanController extends Controller
{
    public function makan()
    {
        echo 'Food';
    }
}