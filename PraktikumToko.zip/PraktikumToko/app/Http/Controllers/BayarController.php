<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BayarController extends Controller
{
    public function bayar()
    {
        echo 'Bayar barang anda disini';
    }
}