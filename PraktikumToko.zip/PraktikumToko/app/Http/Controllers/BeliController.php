<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BeliController extends Controller
{
    public function Beli()
    {
        echo 'Beli barang anda disini';
    }
}