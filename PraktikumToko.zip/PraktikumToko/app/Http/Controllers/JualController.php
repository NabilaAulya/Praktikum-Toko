<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JualController extends Controller
{
    public function jual()
    {
        echo 'jual barang anda disini';
    }
}